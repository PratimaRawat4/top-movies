// Import necessary modules and data
import React from 'react';
import './App.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faStar } from '@fortawesome/free-solid-svg-icons';
import moviesData from './moviesData.json';

// Define the main component of the application
function App() {
  return (
    <div className="App">
      <h1 className="top-movies-title">Top 10 Movies</h1>
      <div className="movie-list">
        {moviesData.map((movie) => (
          
          // Create a card for each movie
          <div className="movie-card">
            <img src={`/images/${movie.image}`} alt={movie.title} />
            <div className="movie-details">
              <h2 className="movie-title">
                {movie.title}
              </h2>
              <div className="movie-description">
                <p>
                 {/* Display the movie duration */}
                  <span>Duration: </span>
                  <span>{movie.description}</span>
                </p>
                {movie.detail && (
                  <p>
                    {/* Display the starring actors if available */}
                    <span>Starring: </span>
                    <span>{movie.detail}</span>
                  </p>
                )}
                <div className="rating">
                  <span>Rating: </span>
                  <span>{movie.rating}</span>
                  <p>
                    {/* Display stars for the movie rating */}
                    Stars:{' '}
                    {Array(Math.round(movie.rating / 2))
                      .fill('')
                      .map((_, i) => (
                        <FontAwesomeIcon icon={faStar} key={i} className="star-filled" />
                      ))}
                  </p>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// Export the App component to be used in other parts of the application
export default App;
